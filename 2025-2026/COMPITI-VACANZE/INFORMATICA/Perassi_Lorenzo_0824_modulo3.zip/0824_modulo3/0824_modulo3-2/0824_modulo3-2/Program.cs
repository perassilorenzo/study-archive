﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0824_modulo3_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Configurazione.Impostazioni);

            Console.WriteLine(MathUtility.Somma(4, 7));
            Console.WriteLine(MathUtility.Media(4, 7));
        }
    }
}
